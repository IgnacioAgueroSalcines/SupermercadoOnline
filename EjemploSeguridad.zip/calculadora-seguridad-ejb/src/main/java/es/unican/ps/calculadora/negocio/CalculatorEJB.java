package es.unican.ps.calculadora.negocio;


import javax.annotation.security.DeclareRoles;
import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.ejb.Stateless;

import es.unican.ps.calculadora.utils.CalculatorEJBRemote;



/**
 * Session Bean implementation class CalculatorEJB
 */
@Stateless
@DeclareRoles({ "PROFESOR", "ALUMNOS" })
public class CalculatorEJB implements CalculatorEJBRemote {

	/**
	 * Default constructor.
	 */
	public CalculatorEJB() {

	}

	@RolesAllowed("PROFESOR")
	public long add(long i, long j) {
		return i + j;
	}

	@RolesAllowed("ALUMNOS")
	public long subtract(long i, long j) {
		return i - j;
	}
	
	@PermitAll
	public long multiply(long i, long j) {
		return i * j;
	}

	@RolesAllowed({"PROFESOR", "ALUMNOS"})
	public double divide(long i, long j) {
		return i / j;
	}

}
