package es.unican.ps.supermercadoOnline.dao;

import es.unican.ps.supermercadoOnline.domain.Articulo;
import es.unican.ps.supermercadoOnline.utils.GenericDAO;

public class ArticuloDAO extends GenericDAO<Articulo>{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	

}
