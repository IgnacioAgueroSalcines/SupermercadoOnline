package es.unican.ps.supermercadoOnline.dao;

import es.unican.ps.supermercadoOnline.domain.Pedido;
import es.unican.ps.supermercadoOnline.utils.GenericDAO;


public class PedidoDAO extends GenericDAO<Pedido>{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	

	
}
