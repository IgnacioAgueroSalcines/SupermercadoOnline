package es.unican.ps.supermercadoOnline.dao;


import es.unican.ps.supermercadoOnline.domain.Usuario;
import es.unican.ps.supermercadoOnline.utils.GenericDAO;

public class UsuarioDAO extends GenericDAO<Usuario> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	

}
