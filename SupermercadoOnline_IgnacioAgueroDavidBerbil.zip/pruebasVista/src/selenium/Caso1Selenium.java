
⁠⁠[16:42, 26/1/2017] +34 676 49 84 26: ⁠⁠⁠Si pide el puto diagrama de clases
⁠⁠⁠⁠16:42⁠⁠⁠⁠⁠
⁠⁠[16:42, 26/1/2017] +34 676 49 84 26: ⁠⁠⁠
🙄
⁠⁠⁠⁠16:42⁠⁠⁠⁠⁠
⁠⁠[17:00, 26/1/2017] Nacho: ⁠⁠⁠pide el diagrama de clases¿?
⁠⁠⁠⁠17:00⁠⁠⁠⁠⁠
⁠⁠[17:00, 26/1/2017] Nacho: ⁠⁠⁠en serio¿?
⁠⁠⁠⁠17:00⁠⁠⁠⁠⁠
⁠⁠[17:01, 26/1/2017] Nacho: ⁠⁠⁠pues, em , cuando llegue me pongo cn el ajaj
⁠⁠⁠⁠17:01⁠⁠⁠⁠⁠
⁠⁠[17:01, 26/1/2017] +34 676 49 84 26: ⁠⁠⁠Si si, en la practica 1 vamos, no sé por qué sudamos de él XD
⁠⁠⁠⁠17:01⁠⁠⁠⁠⁠
⁠⁠[17:02, 26/1/2017] +34 676 49 84 26: ⁠⁠⁠Le estoy haciendo ahora, si tal cuando llegues se revisa y a ver que te parece el documento (voy a meter los diagramas y las pruebas en lo mismo) para enviarlo ya jeje
⁠⁠⁠⁠17:02⁠⁠⁠⁠⁠
⁠⁠[17:02, 26/1/2017] Nacho: ⁠⁠⁠pues ni idea
⁠⁠⁠⁠17:02⁠⁠⁠⁠⁠
⁠⁠[17:02, 26/1/2017] Nacho: ⁠⁠⁠osea que le haces, envias todo, y cuando llegue repasamos
⁠⁠⁠⁠17:02⁠⁠⁠⁠⁠
⁠⁠[17:02, 26/1/2017] Nacho: ⁠⁠⁠y si hay que hacer cambios se reenvia¿?
⁠⁠⁠⁠17:02⁠⁠⁠⁠⁠
⁠⁠[17:03, 26/1/2017] +34 676 49 84 26: ⁠⁠⁠no no o sea, lo repasamos y se envia xd
⁠⁠⁠⁠17:03⁠⁠⁠⁠⁠
⁠⁠[17:03, 26/1/2017] +34 676 49 84 26: ⁠⁠⁠pero no tener que estar a hacer nada a esas horas
⁠⁠⁠⁠17:03⁠⁠⁠⁠⁠
⁠⁠[17:03, 26/1/2017] +34 676 49 84 26: ⁠⁠⁠si tal cambiar algo rápido que quede por ahi y fuera jeje
⁠⁠⁠⁠17:03⁠⁠⁠⁠⁠
⁠⁠[17:03, 26/1/2017] Nacho: ⁠⁠⁠okey okey
⁠⁠⁠⁠17:03⁠⁠⁠⁠⁠
⁠⁠[17:03, 26/1/2017] Nacho: ⁠⁠⁠yo llegare sobre las 7:10
⁠⁠⁠⁠17:03⁠⁠⁠⁠⁠
⁠⁠[17:03, 26/1/2017] Nacho: ⁠⁠⁠mas menos, quieres que hagamos skype¿?
⁠⁠⁠⁠17:03⁠⁠⁠⁠⁠
⁠⁠[17:04, 26/1/2017] +34 676 49 84 26: ⁠⁠⁠Perfecto jejeje imagino que para esa hora ya lo tenga terminado, conectamos para mirar todo y pista
⁠⁠⁠⁠17:04⁠⁠⁠⁠⁠
⁠⁠[17:06, 26/1/2017] Nacho: ⁠⁠⁠me estas haciendo el carrito hoy jajajajajjajajaja
⁠⁠⁠⁠17:06⁠⁠⁠⁠⁠
⁠⁠[17:15, 26/1/2017] +34 676 49 84 26: ⁠⁠⁠Si si
⁠⁠⁠⁠17:15⁠⁠⁠⁠⁠
⁠⁠[17:15, 26/1/2017] +34 676 49 84 26: ⁠⁠⁠ya empiezo a compensar
⁠⁠⁠⁠17:15⁠⁠⁠⁠⁠
⁠⁠[17:15, 26/1/2017] +34 676 49 84 26: ⁠⁠⁠
😂
😂
⁠⁠⁠⁠17:15⁠⁠⁠⁠⁠
⁠⁠[17:48, 26/1/2017] Nacho: ⁠⁠⁠hay que pensar en positivo...ya hemos acabado casi
⁠⁠⁠⁠17:48⁠⁠⁠⁠⁠
⁠⁠[17:48, 26/1/2017] Nacho: ⁠⁠⁠ajaja
⁠⁠⁠⁠17:48⁠⁠⁠⁠⁠
⁠⁠[18:21, 26/1/2017] +34 676 49 84 26: ⁠⁠⁠es lo único bueno xd
⁠⁠⁠⁠18:21⁠⁠⁠⁠⁠
⁠⁠[18:23, 26/1/2017] +34 676 49 84 26: ⁠⁠⁠Oye, que me estos están trabados desde esta mediodia. Que no les guarda las lineas de pedido en la base, pero si el propio pedido. Tienen lo del cascade y tal y luego pues cuando tocan hacen el set de las lineas al pedido total que eso bien
⁠⁠⁠⁠18:23⁠⁠⁠⁠⁠
⁠⁠[18:23, 26/1/2017] +34 676 49 84 26: ⁠⁠⁠A nosotros no nos pasaba algo parecido al principio? que no las persistia? aunque no se si era antes o después de usar lo del cascade y eso
⁠⁠⁠⁠18:23⁠⁠⁠⁠⁠
⁠⁠[18:23, 26/1/2017] +34 676 49 84 26: ⁠⁠⁠por si tienen que configurar algo que se me está pasando
⁠⁠⁠⁠18:23⁠⁠⁠⁠⁠
⁠⁠[18:26, 26/1/2017] +34 676 49 84 26: ⁠⁠⁠Que por cierto soy idiota
⁠⁠⁠⁠18:26⁠⁠⁠⁠⁠
⁠⁠[18:26, 26/1/2017] +34 676 49 84 26: ⁠⁠⁠Me acabo de dar cuenta que está el diagrama de clases en la especificación
⁠⁠⁠⁠18:26⁠⁠⁠⁠⁠
⁠⁠[18:26, 26/1/2017] +34 676 49 84 26: ⁠⁠⁠Vamos que no debería hacer falta no sé
⁠⁠⁠⁠18:26⁠⁠⁠⁠⁠
⁠⁠[18:29, 26/1/2017] +34 676 49 84 26: ⁠⁠⁠ah bueno, pero que se debería corregir si hiciese falta XD
⁠⁠⁠⁠18:29⁠⁠⁠⁠⁠
⁠⁠[19:14, 26/1/2017] Nacho: ⁠⁠⁠Llegue
⁠⁠⁠⁠19:14⁠⁠⁠⁠⁠
 

⁠⁠⁠⁠0:25⁠⁠⁠⁠⁠⁠⁠⁠⁠19:18⁠⁠⁠⁠⁠
⁠⁠[19:19, 26/1/2017] +34 676 49 84 26: ⁠⁠⁠vale me conecto
⁠⁠⁠⁠19:19⁠⁠⁠⁠⁠
⁠⁠[19:24, 26/1/2017] Nacho: ⁠⁠⁠aviso que a las 8 tengo ingles jajajaj
⁠⁠⁠⁠19:24⁠⁠⁠⁠⁠
⁠⁠[19:45, 26/1/2017] Nacho: ⁠⁠⁠tooooonto
⁠⁠⁠⁠19:45⁠⁠⁠⁠⁠
⁠⁠[19:45, 26/1/2017] Nacho: ⁠⁠⁠ajjajajaja
⁠⁠⁠⁠19:45⁠⁠⁠⁠⁠
⁠⁠[19:45, 26/1/2017] +34 676 49 84 26: ⁠⁠⁠Geeenioo
⁠⁠⁠⁠19:45⁠⁠⁠⁠⁠
⁠⁠[19:45, 26/1/2017] Nacho: ⁠⁠⁠llamame cuando actualice
⁠⁠⁠⁠19:45⁠⁠⁠⁠⁠
 

⁠⁠⁠⁠0:22⁠⁠⁠⁠⁠⁠⁠⁠⁠19:45⁠⁠⁠⁠⁠
⁠⁠[19:48, 26/1/2017] Nacho: ⁠⁠⁠package selenium;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.junit.*;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import static org.junit.Assert.*;


public class Caso1Selenium {
	private WebDriver driver;
	private String baseUrl;
	private boolean acceptNextAlert = true;
	private StringBuffer verificationErrors = new StringBuffer();

	@Before
	public void setUp() throws Exception {
		File file = new File("C:\\geckodriver-v0.11.1-win64\\geckodriver.exe");
		System.setProperty("webdriver.gecko.driver", file.getAbsolutePath());
		driver = new ChromeDriver();
		baseUrl = "http://nachopc:8080/";
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	@Test
	public void testCaso1Selenium() throws Exception {
		driver.get(baseUrl + "/supermercadoOnline-web/");
		
		driver.findElement(By.name("j_idt6:j_idt9")).clear();
		driver.findElement(By.name("j_idt6:j_idt9")).sendKeys("Nacho");
		driver.findElement(By.id("j_idt6:date")).clear();
		driver.findElement(By.id("j_idt6:date")).sendKeys("05-05-2017");
		driver.findElement(By.name("j_idt6:j_idt13")).click();
		driver.findElement(By.xpath("//form[@id='formulario']/table/tbody/tr/td[3]")).click();
		//driver.findElement(By.linkText("\"AÃ±adir al carro\"")).click();
		driver.findElement(By.id("stock")).clear();
		driver.findElement(By.id("stock")).sendKeys("4");
		driver.findElement(By.id("anadirButton")).click();
		
		
		driver.findElement(By.linkText("Confirmar Carro")).click();
	}

	@After
	public void tearDown() throws Exception {
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	private boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	private boolean isAlertPresent() {
		try {
			driver.switchTo().alert();
			return true;
		} catch (NoAlertPresentException e) {
			return false;
		}
	}

	private String closeAlertAndGetItsText() {
		try {
			Alert alert = driver.switchTo().alert();
			String alertText = alert.getText();
			if (acceptNextAlert) {
				alert.accept();
			} else {
				alert.dismiss();
			}
			return alertText;
		} finally {
			acceptNextAlert = true;
		}
	}
}