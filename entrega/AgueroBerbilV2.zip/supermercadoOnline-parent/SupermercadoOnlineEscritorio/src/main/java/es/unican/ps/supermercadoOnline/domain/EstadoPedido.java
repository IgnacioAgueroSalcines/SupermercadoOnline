package es.unican.ps.supermercadoOnline.domain;

public enum EstadoPedido {
	
		PENDIENTE,PROCESADO,ENTREGADO;

}
